# CALCULATOR_HOMEMADE
The repository contains the code of a written  calculator in c. 
